// instead of back-end now, it shows one user's time-off requests data

export const EmpTimeoffRequests = [
  {
    startDate: '2023-04-05',
    endDate: '2023-04-15',
    status: 'pending',
  },
  {
    startDate: '2023-05-01',
    endDate: '2023-05-05',
    status: 'pending',
  },
  {
    startDate: '2023-03-30',
    endDate: '2023-04-02',
    status: 'approved',
  },
];

export const AdminEmpDetailedWorkedHours = [
  // worked hours will be given automatically from back-end
  {
    date: '2023-02-01',
    hours: 10,
  },
  {
    date: '2023-02-03',
    hours: 4,
  },
  {
    date: '2023-02-20',
    hours: 12,
  },
  {
    date: '2023-03-03',
    hours: 8,
  },
  {
    date: '2023-03-05',
    hours: 10,
  },
  {
    date: '2023-03-20',
    hours: 6,
  },
];

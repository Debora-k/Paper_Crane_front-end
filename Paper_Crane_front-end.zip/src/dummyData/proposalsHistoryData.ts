export const proposalsHistoryData = [
  {
    id: 1,
    subject: 'This is testing subject',
    sentDate: '2023-04-22',
    clientEmail: '1234@gmail.com',
    file: 'http://localhost:3000/testing.doc',
  },
  {
    id: 2,
    subject: 'This is testing subject',
    sentDate: '2023-03-30',
    clientEmail: '12345@gmail.com',
    link: 'https://www.youtube.com',
  },
  {
    id: 3,
    subject: 'This is testing subject',
    sentDate: '2023-02-27',
    clientEmail: '123456@gmail.com',
    file: 'http://localhost:3000/testing.doc',
  },
];

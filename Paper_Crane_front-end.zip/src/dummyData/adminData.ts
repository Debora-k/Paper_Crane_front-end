export const adminsData = [
    {
      userId: 1,
      name: 'admin1',
      email: 'admin1@asdf.com',
      type: 'developer',
    },
    {
      userId: 2,
      name: 'admin2',
      email: 'admin2@asdf.com',
      type: 'designer',
    },
    {
      userId: 3,
      name: 'admin3',
      email: 'admin3@asdf.com',
      type: 'designer',
    },
    {
      userId: 4,
      name: 'admin4',
      email: 'admin4@asdf.com',
      type: 'developer',
    },
    {
      userId: 5,
      name: 'admin5',
      email: 'admin5@asdf.com',
      type: 'developer',
    },
    {
      userId: 6,
      name: 'admin6',
      email: 'admin6@asdf.com',
      type: 'designer',
    },
    {
      userId: 7,
      name: 'admin7',
      email: 'admin7@asdf.com',
      type: 'developer',
    },
  ];
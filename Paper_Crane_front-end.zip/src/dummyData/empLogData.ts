// instead of back-end now, it shows one user's daily log data

export const EmpLog = [
  {
    date: '2023-03-05',
    workedHours: 6,
    pId: 1,
    //   didn't make an array, because in the log form, tasks part is one textarea
    taskId: 1,
  },
  {
    date: '2023-03-05',
    workedHours: 2,
    pId: 1,
    //   didn't make an array, because in the log form, tasks part is one textarea
    taskId: 5,
  },
  {
    date: '2023-04-01',
    workedHours: 5,
    pId: 2,
    taskId: 7,
  },
  {
    date: '2023-04-03',
    workedHours: 7,
    pId: 2,
    taskId: 8,
  },
  {
    date: '2023-04-05',
    workedHours: 5,
    pId: 3,
    taskId: 14,
  },
];

export const timeoffRequests = [
  {
    userId: 1,
    name: 'emp1',
    email: 'emp1@asdf.com',
    type: 'developer',
    startDate: '2023-03-22',
    endDate: '2023-03-24',
    status: 'pending',
  },
  {
    userId: 2,
    name: 'emp2',
    email: 'emp2@asdf.com',
    type: 'designer',
    startDate: '2023-03-25',
    endDate: '2023-03-26',
    status: 'pending',
  },
  {
    userId: 3,
    name: 'emp3',
    email: 'emp3@asdf.com',
    type: 'designer',
    startDate: '2023-03-30',
    endDate: '2023-04-01',
    status: 'approved',
  },
];

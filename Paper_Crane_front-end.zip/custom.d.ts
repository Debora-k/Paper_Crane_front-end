// let TS understands svg files
// triple slash should be on the top of a file
/// <reference types="react-scripts" />